package org.hootina.platform.utils;

/**
 * @desc:  String工具
 * @author zhangyl
 */
public class StringUtil {
    public static boolean isEmpty(final String str) {
        return (str == null || str.isEmpty());
    }
}
