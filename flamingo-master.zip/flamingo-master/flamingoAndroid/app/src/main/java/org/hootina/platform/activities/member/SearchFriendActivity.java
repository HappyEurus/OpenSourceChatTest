package org.hootina.platform.activities.member;

import android.os.Message;
import android.view.View;

import org.hootina.platform.R;
import org.hootina.platform.activities.BaseActivity;
/*
 * @ 查找好友
 */
public class SearchFriendActivity extends BaseActivity {

	@Override
	public void onClick(View v) {

	}

	@Override
	public void processMessage(Message msg) {
		super.processMessage(msg);
	}

	@Override
	protected int getContentView() {
		return R.layout.activity_searchfriend;
	}

	@Override
	protected void initData() {

	}

	@Override
	protected void setData() {

	}

}
