package org.hootina.platform.utils;

/**
 * @desc   Json工具类
 * @author zhangyl
 * @date   2018.03.30
 */

public final class JsonUtils {
    public static String objectToJsonString(Object obj) {

        return "";
    }
}
