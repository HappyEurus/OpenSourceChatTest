package org.hootina.platform.enums;

public enum TabbarEnum {
	MESSAGE,
	FRIEND,
	MY
}
