package org.hootina.platform.model;

public class TargetInfo {
}
