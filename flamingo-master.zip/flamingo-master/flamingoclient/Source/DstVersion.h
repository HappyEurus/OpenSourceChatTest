#pragma once

#define Flamingo_MAJOR_VERSION    1
#define Flamingo_MINOR_VERSION    0
#define Flamingo_BUILD_VERSION    1526

#define Flamingo_VERSION "1.0.0.1526"
